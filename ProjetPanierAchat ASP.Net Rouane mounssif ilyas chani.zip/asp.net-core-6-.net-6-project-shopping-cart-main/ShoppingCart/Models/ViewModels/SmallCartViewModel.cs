﻿namespace ShoppingCart.Models.ViewModels
{
        public class SmallCartViewModel
        {
                public int NumberOfItems { get; set; }
                public decimal TotalAmount { get; set; }
        }
}
